// const express = require('express');
import express from "express";
const app = express();

app.get("/data",(req,res) => {
    res.json({foo:"bar"});
});
const port = 3001;
app.listen(port, () => {
    console.log("example app listening at port "+ port)
})